#!/bin/bash
# common.sh — 공통 함수: 헤더 조작, 시리얼 복구, 타이밍 측정
# source 해서 사용: source ./common.sh

set -uo pipefail

SLOT0_ORIG="$HOME/secure_boot/slot0_orig.bin"
SLOT0_TEST="$HOME/secure_boot/slot0_test.bin"
FLASH_ADDR="0x08020000"
IMG_SIZE_OFFSET=12          # +0x0C
FAST_THRESHOLD_MS=150       # 이보다 빠르면 1단계 컷으로 판정 (B=17ms 기준)
CAPTURE_TIMEOUT_S=3         # 응답 대기 최대 시간

# ---- 시리얼 좀비 상태 자동 복구 -------------------------------------------
recover_serial() {
  local iface
  iface=$(readlink -f /sys/class/tty/ttyACM0/device 2>/dev/null | grep -oE '[0-9]+-[0-9.]+:[0-9.]+$')
  if [ -z "$iface" ]; then
    echo "  [WARN] ttyACM0 인터페이스 경로를 못 찾음, 기본값 1-1:1.2 시도" >&2
    iface="1-1:1.2"
  fi
  echo -n "$iface" | sudo tee /sys/bus/usb/drivers/cdc_acm/unbind >/dev/null 2>&1
  sleep 1
  echo -n "$iface" | sudo tee /sys/bus/usb/drivers/cdc_acm/bind >/dev/null 2>&1
  sleep 1
  stty -F /dev/ttyACM0 115200 raw -echo 2>/dev/null
}

# 최근 dmesg에 -104(ECONNRESET) 좀비가 쌓이고 있는지 확인
is_serial_zombie() {
  local recent
  recent=$(dmesg | tail -5)
  echo "$recent" | grep -q "urb->status -104"
}

# ---- 헤더 img_size 필드 조작 ----------------------------------------------
# set_img_size <hex_value>   예: set_img_size 0x3c6e
set_img_size() {
  local hexval="$1"
  cp "$SLOT0_ORIG" "$SLOT0_TEST"
  # little-endian 4바이트로 변환해서 offset 12에 기록
  printf '%08x' "$hexval" | \
    sed -E 's/(..)(..)(..)(..)/\4\3\2\1/' | \
    xxd -r -p | \
    dd of="$SLOT0_TEST" bs=1 seek=$IMG_SIZE_OFFSET conv=notrunc 2>/dev/null
}

# ---- 플래시 쓰기 + 리셋 + 타이밍 측정 -------------------------------------
# flash_and_measure  →  stdout으로 "elapsed_ms classification" 출력
# classification: FAST(1단계 컷 추정) / SLOW(2단계 진입 추정) / NONE(응답 없음)
flash_and_measure() {
  st-flash --connect-under-reset write "$SLOT0_TEST" "$FLASH_ADDR" >/dev/null 2>&1 || {
    echo "0 WRITE_FAILED"
    return 1
  }

  if is_serial_zombie; then
    recover_serial
  fi

  local start_ns end_ns elapsed_ms
  start_ns=$(date +%s%N)

  # 리셋 트리거 + 캡처를 동시에: 리셋 직후 첫 바이트가 올 때까지 폴링
  st-flash --connect-under-reset reset >/dev/null 2>&1

  # 첫 바이트가 들어올 때까지 짧은 간격으로 폴링 (최대 CAPTURE_TIMEOUT_S)
  local got_byte=0
  local deadline=$((SECONDS + CAPTURE_TIMEOUT_S))
  while [ $SECONDS -lt $deadline ]; do
    if timeout 0.05 head -c1 /dev/ttyACM0 2>/dev/null | grep -q .; then
      got_byte=1
      break
    fi
  done

  end_ns=$(date +%s%N)
  elapsed_ms=$(( (end_ns - start_ns) / 1000000 ))

  if [ "$got_byte" -eq 0 ]; then
    echo "$elapsed_ms NONE"
    return 2
  fi

  if [ "$elapsed_ms" -lt "$FAST_THRESHOLD_MS" ]; then
    echo "$elapsed_ms FAST"
  else
    echo "$elapsed_ms SLOW"
  fi
}
