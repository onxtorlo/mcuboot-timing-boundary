#!/bin/bash
# exp1_boundary_scan.sh — 실험 1: 1단계 컷(FAST) ↔ 2단계 진입(SLOW) 전이 지점을 이진탐색으로 특정
#
# 사용법: ./exp1_boundary_scan.sh
# 결과: 콘솔 출력 + boundary_scan_log.csv

source ./common.sh

LOG_CSV="boundary_scan_log.csv"
echo "step,img_size_hex,elapsed_ms,classification" > "$LOG_CSV"

LOW=0x3c6f      # 케이스 B: 이미 FAST로 확인됨
HIGH=0xbfdff    # 케이스 C: 이미 SLOW로 확인됨
THEORY=$((0xC0000 - 0x20))   # 슬롯크기 - hdr_size = 이론적 경계

echo "=== 실험 1: 경계 이진탐색 시작 ==="
echo "탐색 범위: $LOW (FAST 확인됨) ~ $HIGH (SLOW 확인됨)"
printf "이론적 경계 (슬롯크기-hdr_size): 0x%x\n" "$THEORY"
echo

step=0
low_dec=$((LOW))
high_dec=$((HIGH))

while [ $((high_dec - low_dec)) -gt 1 ]; do
  step=$((step+1))
  mid_dec=$(( (low_dec + high_dec) / 2 ))
  mid_hex=$(printf '0x%x' "$mid_dec")

  echo -n "[step $step] 시도값=$mid_hex ... "
  set_img_size "$mid_hex"
  result=$(flash_and_measure)
  elapsed=$(echo "$result" | awk '{print $1}')
  cls=$(echo "$result" | awk '{print $2}')
  echo "${elapsed}ms → $cls"
  echo "$step,$mid_hex,$elapsed,$cls" >> "$LOG_CSV"

  case "$cls" in
    FAST)
      low_dec=$mid_dec   # 여전히 1단계 컷 → 경계는 더 위쪽
      ;;
    SLOW)
      high_dec=$mid_dec  # 2단계까지 진입 → 경계는 더 아래쪽
      ;;
    NONE|WRITE_FAILED)
      echo "  [WARN] 이번 시도 응답 없음/쓰기 실패, 재시도"
      step=$((step-1))
      ;;
  esac
done

boundary_hex=$(printf '0x%x' "$low_dec")
echo
echo "=== 결과 ==="
echo "실측 경계 (FAST 쪽 마지막 값): $boundary_hex"
printf "이론적 경계값:               0x%x\n" "$THEORY"
if [ "$low_dec" -eq "$THEORY" ] || [ "$high_dec" -eq "$THEORY" ]; then
  echo "→ 이론값과 일치 확인됨"
else
  echo "→ 이론값과 차이 있음 (표/본문에서 원인 분석 필요)"
fi
echo "상세 로그: $LOG_CSV"
